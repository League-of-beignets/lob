<?php
/**
 * Module Helper File
 *
 * @package         aeSecure's QuickIcon Administration module
 * @version         1.0
 *
 * @author          Christophe Avonture <christophe@avonture.com>
 * @link            http://www.aesecure.com
 * @copyright       Copyright © 2014-2015 NoNumber All Rights Reserved
 * @license         http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

if (!defined('_AESECURE_QUICKICON_MODULE')) {

   /** ensure that functions are declared only once */
   define('_AESECURE_QUICKICON_MODULE', 1);
   
   // Get the relative path to the aeSecure module (f.i. /modules/mod_aesecure/)
   $sPath=str_replace(DIRECTORY_SEPARATOR, '/', str_replace(JPATH_ADMINISTRATOR,'',dirname(__FILE__))).'/';

   function aeSecureQuickIconButton($sLink, $sImage, $sPath, $sText) {

      global $mainframe;
      $lang=&JFactory::getLanguage();

	  return
	     '<div style="float:'.($lang->isRTL()?'right':'left').'">'.
            '<div class="icon">'.
               '<a href="'.$sLink.'" target="_blank" title="'.JText::_('MOD_AESECURE_QUICKICONS_SETUP').'">'.JHTML::_('image.site', $sImage, $sPath.'assets/images/', NULL, NULL, $sText).'<span>'.$sText.'</span></a>'.
            '</div>'.
         '</div>'; 
		 
   }
   
   global $mainframe;

   $lang=&JFactory::getLanguage();
   $doc=&JFactory::getDocument();
   $doc->addStyleSheet(ltrim($sPath,'/').'assets/css/aesecure.css');
   
   $lang->load('mod_aesecure_quickicons', JPATH_ADMINISTRATOR, $lang->getTag(), true);
   
   // Check if aeSecure exists on the site
   if (!file_exists($file=JPATH_SITE.'/aesecure/configuration/configuration.json')) {
      $sLink="javascript:alert('".JText::_('MOD_AESECURE_QUICKICONS_MISSING',true)."');";
   } else {
      $info=file_get_contents($file, FILE_USE_INCLUDE_PATH);
      $arr=(array) json_decode($info,true);      
      $sLink='../aesecure/setup.php?'.$arr['key'];
   }  
   
   echo 
      '<div id="cpanelaeSecure">'.
         aeSecureQuickIconButton($sLink, 'icon-48-aesecure.png', $sPath, JText::_('aeSecure') ).	
      '</div>';
	  
}